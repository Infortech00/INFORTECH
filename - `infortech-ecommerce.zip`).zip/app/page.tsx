import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import FeaturedProducts from "@/components/featured-products"
import CategoryGrid from "@/components/category-grid"
import MainBanner from "@/components/main-banner"
import ProductCarousel from "@/components/product-carousel"
import NewsletterSection from "@/components/newsletter-section"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        <section className="py-6">
          <div className="container">
            <MainBanner />
          </div>
        </section>

        <section className="py-8 bg-gray-50">
          <div className="container">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Categorias</h2>
              <Link href="/produtos" className="text-purple-600 hover:underline">
                Ver todas
              </Link>
            </div>
            <CategoryGrid />
          </div>
        </section>

        <section className="py-8">
          <div className="container">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Ofertas em Destaque</h2>
              <Badge variant="outline" className="bg-purple-100 text-purple-800 hover:bg-purple-200">
                Promoção
              </Badge>
            </div>
            <FeaturedProducts />
          </div>
        </section>

        <section className="py-8 bg-gray-50">
          <div className="container">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Monte seu PC</h2>
              <Link href="/monte-seu-pc" className="text-purple-600 hover:underline">
                Começar agora
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="overflow-hidden border-0 shadow-lg">
                <CardContent className="p-0">
                  <div className="relative h-[200px] bg-gradient-to-r from-purple-700 to-purple-500 flex items-center justify-center p-6">
                    <div className="text-white text-center">
                      <h3 className="text-xl font-bold mb-2">Monte seu PC Gamer</h3>
                      <p className="mb-4">Escolha os componentes ideais para seu setup gaming</p>
                      <Link
                        href="/monte-seu-pc?tipo=gamer"
                        className="inline-block bg-white text-purple-700 px-4 py-2 rounded font-medium hover:bg-gray-100 transition-colors"
                      >
                        Montar agora
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="overflow-hidden border-0 shadow-lg">
                <CardContent className="p-0">
                  <div className="relative h-[200px] bg-gradient-to-r from-gray-700 to-gray-500 flex items-center justify-center p-6">
                    <div className="text-white text-center">
                      <h3 className="text-xl font-bold mb-2">PC para Trabalho</h3>
                      <p className="mb-4">Configurações otimizadas para produtividade</p>
                      <Link
                        href="/monte-seu-pc?tipo=trabalho"
                        className="inline-block bg-white text-gray-700 px-4 py-2 rounded font-medium hover:bg-gray-100 transition-colors"
                      >
                        Montar agora
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-8">
          <div className="container">
            <Tabs defaultValue="hardware" className="w-full">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold">Produtos Populares</h2>
                <TabsList>
                  <TabsTrigger value="hardware">Hardware</TabsTrigger>
                  <TabsTrigger value="perifericos">Periféricos</TabsTrigger>
                  <TabsTrigger value="monitores">Monitores</TabsTrigger>
                </TabsList>
              </div>
              <TabsContent value="hardware">
                <ProductCarousel category="hardware" />
              </TabsContent>
              <TabsContent value="perifericos">
                <ProductCarousel category="perifericos" />
              </TabsContent>
              <TabsContent value="monitores">
                <ProductCarousel category="monitores" />
              </TabsContent>
            </Tabs>
          </div>
        </section>

        <NewsletterSection />
      </main>
    </div>
  )
}
