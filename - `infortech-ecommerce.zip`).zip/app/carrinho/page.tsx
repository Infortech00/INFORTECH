"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { useStore } from "@/lib/store"
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function CarrinhoPage() {
  const { cart, updateQuantity, removeFromCart, getCartTotal, clearCart } = useStore()
  const [couponCode, setCouponCode] = useState("")
  const [discount, setDiscount] = useState(0)
  const { toast } = useToast()

  const subtotal = getCartTotal()
  const shipping = subtotal > 500 ? 0 : 29.9
  const total = subtotal - discount + shipping

  const handleQuantityChange = (productId: number, newQuantity: number) => {
    if (newQuantity < 1) return
    updateQuantity(productId, newQuantity)
  }

  const handleRemoveItem = (productId: number, productName: string) => {
    removeFromCart(productId)
    toast({
      title: "Produto removido",
      description: `${productName} foi removido do carrinho.`,
    })
  }

  const handleApplyCoupon = () => {
    // Simulação de cupons
    const coupons: Record<string, number> = {
      DESCONTO10: 0.1,
      BEMVINDO: 0.05,
      FRETEGRATIS: 0.15,
    }

    const couponDiscount = coupons[couponCode.toUpperCase()]
    if (couponDiscount) {
      setDiscount(subtotal * couponDiscount)
      toast({
        title: "Cupom aplicado!",
        description: `Desconto de ${(couponDiscount * 100).toFixed(0)}% aplicado.`,
      })
    } else {
      toast({
        title: "Cupom inválido",
        description: "O cupom informado não é válido.",
        variant: "destructive",
      })
    }
  }

  if (cart.length === 0) {
    return (
      <div className="container py-8">
        <div className="text-center py-16">
          <ShoppingBag className="h-24 w-24 mx-auto text-gray-400 mb-4" />
          <h1 className="text-2xl font-bold mb-2">Seu carrinho está vazio</h1>
          <p className="text-gray-600 mb-6">Adicione produtos ao carrinho para continuar comprando.</p>
          <Button asChild className="bg-purple-600 hover:bg-purple-700">
            <Link href="/produtos">Continuar comprando</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-8">
      <div className="mb-6">
        <Link href="/" className="flex items-center text-sm text-gray-600 hover:text-purple-600">
          <ArrowLeft className="h-4 w-4 mr-1" />
          Continuar comprando
        </Link>
      </div>

      <h1 className="text-3xl font-bold mb-8">Carrinho de Compras</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Lista de produtos */}
        <div className="lg:col-span-2 space-y-4">
          {cart.map((item) => (
            <Card key={item.id}>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      className="w-full h-full object-contain"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium line-clamp-2">{item.name}</h3>
                    <p className="text-sm text-gray-600 mt-1">Marca: {item.brand}</p>
                    <p className="text-lg font-bold text-purple-600 mt-2">R$ {item.price.toFixed(2)}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                      disabled={item.quantity <= 1}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="w-12 text-center font-medium">{item.quantity}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="text-right">
                    <p className="font-bold">R$ {(item.price * item.quantity).toFixed(2)}</p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveItem(item.id, item.name)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50 mt-2"
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Remover
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Resumo do pedido */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Resumo do Pedido</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span>
                  Subtotal ({cart.length} {cart.length === 1 ? "item" : "itens"})
                </span>
                <span>R$ {subtotal.toFixed(2)}</span>
              </div>

              {discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Desconto</span>
                  <span>-R$ {discount.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Frete</span>
                <span>{shipping === 0 ? "Grátis" : `R$ ${shipping.toFixed(2)}`}</span>
              </div>

              <Separator />

              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>R$ {total.toFixed(2)}</span>
              </div>

              {subtotal < 500 && <p className="text-sm text-gray-600">Frete grátis para compras acima de R$ 500,00</p>}
            </CardContent>
            <CardFooter className="flex flex-col gap-4">
              <Button asChild className="w-full bg-purple-600 hover:bg-purple-700">
                <Link href="/checkout">Finalizar Compra</Link>
              </Button>
              <Button variant="outline" className="w-full bg-transparent" asChild>
                <Link href="/produtos">Continuar Comprando</Link>
              </Button>
            </CardFooter>
          </Card>

          {/* Cupom de desconto */}
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-lg">Cupom de Desconto</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Input
                  placeholder="Digite o código do cupom"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                />
                <Button onClick={handleApplyCoupon} variant="outline">
                  Aplicar
                </Button>
              </div>
              <div className="mt-4 text-sm text-gray-600">
                <p className="font-medium mb-2">Cupons disponíveis:</p>
                <ul className="space-y-1">
                  <li>• DESCONTO10 - 10% de desconto</li>
                  <li>• BEMVINDO - 5% de desconto</li>
                  <li>• FRETEGRATIS - 15% de desconto</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
