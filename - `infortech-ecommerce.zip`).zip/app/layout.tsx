import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Header from "@/components/header"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "InfoTech - Sua Loja de Tecnologia",
  description:
    "A melhor loja de tecnologia do Brasil. Produtos de qualidade, manutenção especializada e desenvolvimento de sites.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>
        <Header />
        {children}
        <Toaster />
        <footer className="bg-gray-900 text-gray-300">
          <div className="container py-12">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <h3 className="text-lg font-bold mb-4 text-white">InfoTech</h3>
                <p className="text-sm">
                  Sua empresa completa de tecnologia, oferecendo produtos de qualidade, manutenção especializada e
                  desenvolvimento de sites.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-4 text-white">Produtos</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <a href="/categoria/processadores" className="hover:text-white">
                      Processadores
                    </a>
                  </li>
                  <li>
                    <a href="/categoria/placas-video" className="hover:text-white">
                      Placas de Vídeo
                    </a>
                  </li>
                  <li>
                    <a href="/categoria/monitores" className="hover:text-white">
                      Monitores
                    </a>
                  </li>
                  <li>
                    <a href="/categoria/perifericos" className="hover:text-white">
                      Periféricos
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-4 text-white">Serviços</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <a href="/servicos/manutencao" className="hover:text-white">
                      Manutenção
                    </a>
                  </li>
                  <li>
                    <a href="/servicos/montagem" className="hover:text-white">
                      Montagem de PCs
                    </a>
                  </li>
                  <li>
                    <a href="/servicos/sites" className="hover:text-white">
                      Desenvolvimento Web
                    </a>
                  </li>
                  <li>
                    <a href="/servicos/suporte" className="hover:text-white">
                      Suporte Técnico
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-4 text-white">Contato</h3>
                <ul className="space-y-2 text-sm">
                  <li>contato@infortech.com.br</li>
                  <li>(11) 9999-9999</li>
                  <li>Av. Tecnologia, 1000</li>
                  <li>São Paulo - SP</li>
                </ul>
              </div>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8 text-sm text-center">
              <p>© 2025 InfoTech. Todos os direitos reservados.</p>
            </div>
          </div>
        </footer>
      </body>
    </html>
  )
}
