import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { ShoppingCart, Heart, Share2, ArrowLeft, Star, Truck, Shield, CreditCard } from "lucide-react"

export default function ProductPage({ params }: { params: { slug: string } }) {
  // Normalmente, você buscaria os dados do produto com base no slug
  // Aqui estamos usando dados fictícios para demonstração
  const product = {
    id: 1,
    name: "Processador AMD Ryzen 7 5800X 8-Core, 16-Thread, 3.8GHz (4.7GHz Max Boost)",
    price: 1899.9,
    oldPrice: 2299.9,
    discount: 17,
    rating: 4.8,
    reviews: 156,
    stock: 15,
    sku: "AMD-R7-5800X",
    description:
      "O AMD Ryzen 7 5800X é um processador de alto desempenho com 8 núcleos e 16 threads, ideal para jogos e tarefas de produtividade. Com velocidade base de 3.8GHz e boost de até 4.7GHz, oferece desempenho excepcional para qualquer tarefa.",
    features: [
      "8 núcleos e 16 threads",
      "Velocidade base de 3.8GHz",
      "Velocidade máxima de 4.7GHz",
      "Cache L3 de 32MB",
      "TDP de 105W",
      "Suporte a PCIe 4.0",
      "Desbloqueado para overclock",
    ],
    specifications: {
      Marca: "AMD",
      Modelo: "Ryzen 7 5800X",
      Núcleos: "8",
      Threads: "16",
      "Frequência base": "3.8GHz",
      "Frequência máxima": "4.7GHz",
      "Cache L3": "32MB",
      TDP: "105W",
      Socket: "AM4",
      "Processo de fabricação": "7nm",
      "Cooler incluso": "Não",
    },
    images: [
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
      "/placeholder.svg?height=600&width=600",
    ],
    relatedProducts: [
      {
        id: 2,
        name: "Processador AMD Ryzen 9 5900X",
        price: 2699.9,
        image: "/placeholder.svg?height=200&width=200",
        link: "/produto/processador-amd-ryzen-9-5900x",
      },
      {
        id: 3,
        name: "Processador Intel Core i7-12700K",
        price: 2499.9,
        image: "/placeholder.svg?height=200&width=200",
        link: "/produto/processador-intel-core-i7-12700k",
      },
      {
        id: 4,
        name: "Placa-Mãe ASUS ROG Strix B550-F",
        price: 1299.9,
        image: "/placeholder.svg?height=200&width=200",
        link: "/produto/placa-mae-asus-rog-strix-b550f",
      },
      {
        id: 5,
        name: "Memória RAM Corsair Vengeance RGB Pro 32GB",
        price: 999.9,
        image: "/placeholder.svg?height=200&width=200",
        link: "/produto/memoria-ram-corsair-vengeance-rgb-pro-32gb",
      },
    ],
  }

  return (
    <div className="container py-8">
      <div className="mb-6">
        <Link href="/" className="flex items-center text-sm text-gray-600 hover:text-purple-600">
          <ArrowLeft className="h-4 w-4 mr-1" />
          Voltar para a página inicial
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Imagens do produto */}
        <div className="space-y-4">
          <div className="bg-white rounded-lg overflow-hidden border shadow-sm">
            <img
              src={product.images[0] || "/placeholder.svg"}
              alt={product.name}
              className="w-full h-auto object-contain aspect-square"
            />
          </div>
          <div className="grid grid-cols-4 gap-2">
            {product.images.map((image, index) => (
              <div
                key={index}
                className="bg-white rounded-lg overflow-hidden border cursor-pointer hover:border-purple-500"
              >
                <img
                  src={image || "/placeholder.svg"}
                  alt={`${product.name} - Imagem ${index + 1}`}
                  className="w-full h-auto object-contain aspect-square"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Informações do produto */}
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-bold">{product.name}</h1>
            <div className="flex items-center gap-2 mt-2">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-600">
                {product.rating} ({product.reviews} avaliações)
              </span>
              <span className="text-sm text-gray-600">|</span>
              <span className="text-sm text-green-600">Em estoque: {product.stock} unidades</span>
            </div>
            <div className="text-sm text-gray-600 mt-1">SKU: {product.sku}</div>
          </div>

          <div className="space-y-2">
            <div className="text-sm text-gray-500 line-through">De: R$ {product.oldPrice.toFixed(2)}</div>
            <div className="flex items-center gap-2">
              <span className="text-3xl font-bold text-purple-600">R$ {product.price.toFixed(2)}</span>
              <Badge className="bg-purple-600 hover:bg-purple-700">-{product.discount}%</Badge>
            </div>
            <div className="text-sm text-gray-600">Em até 12x de R$ {(product.price / 12).toFixed(2)} sem juros</div>
            <div className="text-sm text-gray-600">
              Ou R$ {(product.price * 0.9).toFixed(2)} à vista (10% de desconto)
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button className="gap-2 flex-1 bg-purple-600 hover:bg-purple-700">
              <ShoppingCart className="h-4 w-4" />
              Adicionar ao carrinho
            </Button>
            <Button
              variant="outline"
              className="gap-2 flex-1 border-purple-200 hover:bg-purple-50 hover:text-purple-700 bg-transparent"
            >
              <Heart className="h-4 w-4" />
              Adicionar à lista de desejos
            </Button>
            <Button variant="ghost" size="icon" className="hidden sm:flex">
              <Share2 className="h-5 w-5" />
              <span className="sr-only">Compartilhar</span>
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="flex items-center gap-2 text-sm">
              <Truck className="h-5 w-5 text-purple-600" />
              <div>
                <div className="font-medium">Entrega rápida</div>
                <div className="text-gray-600">Em até 3 dias úteis</div>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Shield className="h-5 w-5 text-purple-600" />
              <div>
                <div className="font-medium">Garantia</div>
                <div className="text-gray-600">12 meses de garantia</div>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CreditCard className="h-5 w-5 text-purple-600" />
              <div>
                <div className="font-medium">Pagamento seguro</div>
                <div className="text-gray-600">Diversas formas de pagamento</div>
              </div>
            </div>
          </div>

          <div className="border-t pt-6">
            <h2 className="font-medium mb-2">Descrição</h2>
            <p className="text-gray-700">{product.description}</p>
          </div>

          <div>
            <h2 className="font-medium mb-2">Destaques</h2>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {product.features.map((feature, index) => (
                <li key={index} className="flex items-center gap-2 text-sm text-gray-700">
                  <div className="h-1.5 w-1.5 rounded-full bg-purple-600"></div>
                  {feature}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="mt-12">
        <Tabs defaultValue="specifications">
          <TabsList className="w-full justify-start border-b rounded-none bg-transparent h-auto p-0">
            <TabsTrigger
              value="specifications"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-purple-600 data-[state=active]:bg-transparent data-[state=active]:shadow-none py-3 text-base"
            >
              Especificações
            </TabsTrigger>
            <TabsTrigger
              value="reviews"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-purple-600 data-[state=active]:bg-transparent data-[state=active]:shadow-none py-3 text-base"
            >
              Avaliações
            </TabsTrigger>
            <TabsTrigger
              value="support"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-purple-600 data-[state=active]:bg-transparent data-[state=active]:shadow-none py-3 text-base"
            >
              Suporte
            </TabsTrigger>
          </TabsList>
          <TabsContent value="specifications" className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-medium mb-4">Especificações Técnicas</h3>
                <div className="space-y-2">
                  {Object.entries(product.specifications).map(([key, value], index) => (
                    <div key={index} className="grid grid-cols-2 py-2 border-b last:border-0">
                      <div className="text-gray-600">{key}</div>
                      <div className="font-medium">{value}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-medium mb-4">Requisitos do Sistema</h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                    <span>Placa-mãe com socket AM4</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                    <span>Chipset compatível (série 500, 400 ou 300 com BIOS atualizada)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                    <span>Cooler compatível (não incluso na embalagem)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                    <span>Fonte de alimentação com potência adequada (recomendado 650W ou superior)</span>
                  </li>
                </ul>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="reviews" className="pt-6">
            <div className="text-center py-12">
              <h3 className="text-lg font-medium mb-2">Avaliações dos Clientes</h3>
              <p className="text-gray-600 mb-4">Seja o primeiro a avaliar este produto!</p>
              <Button>Escrever avaliação</Button>
            </div>
          </TabsContent>
          <TabsContent value="support" className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-medium mb-4">Suporte Técnico</h3>
                <p className="text-gray-700 mb-4">
                  Precisa de ajuda com seu produto? Nossa equipe de suporte técnico está disponível para ajudar com
                  qualquer dúvida ou problema.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-purple-600"
                      >
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                      </svg>
                    </div>
                    <div>
                      <div className="font-medium">Telefone</div>
                      <div className="text-gray-600">(11) 9999-9999</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-purple-600"
                      >
                        <rect width="20" height="16" x="2" y="4" rx="2" />
                        <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                      </svg>
                    </div>
                    <div>
                      <div className="font-medium">Email</div>
                      <div className="text-gray-600">suporte@infortech.com.br</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-purple-600"
                      >
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                      </svg>
                    </div>
                    <div>
                      <div className="font-medium">Chat</div>
                      <div className="text-gray-600">Disponível de seg. a sex. das 9h às 18h</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-medium mb-4">Perguntas Frequentes</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium">Este processador vem com cooler?</h4>
                    <p className="text-gray-700 mt-1">
                      Não, o AMD Ryzen 7 5800X não inclui cooler na embalagem. É necessário adquirir um cooler
                      compatível separadamente.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium">Qual placa-mãe é compatível com este processador?</h4>
                    <p className="text-gray-700 mt-1">
                      O Ryzen 7 5800X é compatível com placas-mãe socket AM4 com chipsets série 500 (X570, B550) e série
                      400 (X470, B450) com BIOS atualizada.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium">Qual a potência de fonte recomendada?</h4>
                    <p className="text-gray-700 mt-1">
                      Recomendamos uma fonte de alimentação de pelo menos 650W de boa qualidade, especialmente se for
                      utilizar com uma placa de vídeo dedicada de alto desempenho.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <div className="mt-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Produtos Relacionados</h2>
          <Link href="/produtos" className="text-purple-600 hover:underline">
            Ver mais
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {product.relatedProducts.map((relatedProduct) => (
            <Card key={relatedProduct.id} className="overflow-hidden border-0 shadow-md hover:shadow-lg transition-all">
              <Link href={relatedProduct.link}>
                <div className="p-4">
                  <div className="aspect-square flex items-center justify-center bg-gray-50 rounded-lg overflow-hidden">
                    <img
                      src={relatedProduct.image || "/placeholder.svg"}
                      alt={relatedProduct.name}
                      className="object-contain h-full w-full p-4"
                    />
                  </div>
                </div>
              </Link>
              <CardContent className="p-4 pt-0">
                <Link href={relatedProduct.link} className="hover:text-purple-600">
                  <h3 className="font-medium line-clamp-2 h-12">{relatedProduct.name}</h3>
                </Link>
                <div className="mt-2">
                  <div className="text-lg font-bold text-purple-600">R$ {relatedProduct.price.toFixed(2)}</div>
                  <div className="text-sm text-gray-600">Em até 12x de R$ {(relatedProduct.price / 12).toFixed(2)}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
