"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Check, Cpu, HardDrive, Monitor } from "lucide-react"

export default function MonteSeuPcPage() {
  const [totalPrice, setTotalPrice] = useState(0)
  const [selectedComponents, setSelectedComponents] = useState<Record<string, any>>({})

  const handleComponentSelect = (category: string, component: any) => {
    const newSelectedComponents = {
      ...selectedComponents,
      [category]: component,
    }

    setSelectedComponents(newSelectedComponents)

    // Calcular o preço total
    const newTotal = Object.values(newSelectedComponents).reduce(
      (sum: number, item: any) => sum + (item?.price || 0),
      0,
    )
    setTotalPrice(newTotal)
  }

  return (
    <div className="container py-8">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl font-bold mb-4">Monte Seu PC</h1>
        <p className="text-gray-600">
          Personalize seu computador escolhendo os componentes ideais para suas necessidades. Nossa ferramenta
          interativa facilita a montagem do seu PC dos sonhos.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Tabs defaultValue="gaming" className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold">Escolha seu perfil</h2>
              <TabsList>
                <TabsTrigger value="gaming">Gamer</TabsTrigger>
                <TabsTrigger value="work">Trabalho</TabsTrigger>
                <TabsTrigger value="custom">Personalizado</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="gaming">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <Card className="overflow-hidden border-2 border-purple-500">
                  <CardHeader className="bg-purple-500 text-white">
                    <CardTitle>PC Gamer Iniciante</CardTitle>
                    <CardDescription className="text-purple-100">Ideal para jogos em 1080p</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="font-medium">Processador</span>
                        <span>AMD Ryzen 5 5600X</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Placa de Vídeo</span>
                        <span>NVIDIA RTX 3060</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Memória RAM</span>
                        <span>16GB DDR4 3200MHz</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Armazenamento</span>
                        <span>SSD NVMe 500GB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Preço</span>
                        <span className="font-bold">R$ 5.499,90</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Selecionar</Button>
                  </CardFooter>
                </Card>

                <Card className="overflow-hidden border-2 border-purple-700">
                  <CardHeader className="bg-purple-700 text-white">
                    <CardTitle>PC Gamer Avançado</CardTitle>
                    <CardDescription className="text-purple-100">Ideal para jogos em 1440p</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="font-medium">Processador</span>
                        <span>AMD Ryzen 7 5800X</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Placa de Vídeo</span>
                        <span>NVIDIA RTX 3070 Ti</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Memória RAM</span>
                        <span>32GB DDR4 3600MHz</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Armazenamento</span>
                        <span>SSD NVMe 1TB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Preço</span>
                        <span className="font-bold">R$ 8.999,90</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Selecionar</Button>
                  </CardFooter>
                </Card>
              </div>

              <Card className="overflow-hidden border-2 border-purple-900">
                <CardHeader className="bg-purple-900 text-white">
                  <CardTitle>PC Gamer Entusiasta</CardTitle>
                  <CardDescription className="text-purple-100">Ideal para jogos em 4K e streaming</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="font-medium">Processador</span>
                        <span>AMD Ryzen 9 5950X</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Placa de Vídeo</span>
                        <span>NVIDIA RTX 4080</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Memória RAM</span>
                        <span>64GB DDR4 3600MHz</span>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="font-medium">Armazenamento</span>
                        <span>SSD NVMe 2TB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Refrigeração</span>
                        <span>Watercooler 360mm</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Preço</span>
                        <span className="font-bold">R$ 15.999,90</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">Selecionar</Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="work">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <Card className="overflow-hidden border-2 border-gray-500">
                  <CardHeader className="bg-gray-500 text-white">
                    <CardTitle>PC Office Básico</CardTitle>
                    <CardDescription className="text-gray-100">Ideal para tarefas do dia a dia</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="font-medium">Processador</span>
                        <span>Intel Core i3 12100</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Placa de Vídeo</span>
                        <span>Integrada Intel UHD</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Memória RAM</span>
                        <span>8GB DDR4 2666MHz</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Armazenamento</span>
                        <span>SSD SATA 256GB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Preço</span>
                        <span className="font-bold">R$ 2.499,90</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Selecionar</Button>
                  </CardFooter>
                </Card>

                <Card className="overflow-hidden border-2 border-gray-700">
                  <CardHeader className="bg-gray-700 text-white">
                    <CardTitle>PC Produtividade</CardTitle>
                    <CardDescription className="text-gray-100">Ideal para trabalho profissional</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="font-medium">Processador</span>
                        <span>Intel Core i5 12600K</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Placa de Vídeo</span>
                        <span>NVIDIA RTX 3050</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Memória RAM</span>
                        <span>16GB DDR4 3200MHz</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Armazenamento</span>
                        <span>SSD NVMe 512GB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Preço</span>
                        <span className="font-bold">R$ 4.999,90</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Selecionar</Button>
                  </CardFooter>
                </Card>
              </div>

              <Card className="overflow-hidden border-2 border-gray-900">
                <CardHeader className="bg-gray-900 text-white">
                  <CardTitle>Workstation Profissional</CardTitle>
                  <CardDescription className="text-gray-100">
                    Ideal para edição de vídeo e renderização 3D
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="font-medium">Processador</span>
                        <span>Intel Core i9 12900K</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Placa de Vídeo</span>
                        <span>NVIDIA RTX 3080</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Memória RAM</span>
                        <span>64GB DDR4 3600MHz</span>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="font-medium">Armazenamento</span>
                        <span>SSD NVMe 2TB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Refrigeração</span>
                        <span>Watercooler 240mm</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Preço</span>
                        <span className="font-bold">R$ 12.999,90</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">Selecionar</Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="custom">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Cpu className="h-5 w-5 text-purple-600" />
                      <CardTitle>Processador</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Select
                      onValueChange={(value) => {
                        const processors = {
                          ryzen5: { name: "AMD Ryzen 5 5600X", price: 1299.9 },
                          ryzen7: { name: "AMD Ryzen 7 5800X", price: 1899.9 },
                          ryzen9: { name: "AMD Ryzen 9 5900X", price: 2699.9 },
                          "intel-i5": { name: "Intel Core i5 12600K", price: 1499.9 },
                          "intel-i7": { name: "Intel Core i7 12700K", price: 2199.9 },
                          "intel-i9": { name: "Intel Core i9 12900K", price: 3299.9 },
                        }
                        handleComponentSelect("processor", processors[value as keyof typeof processors])
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um processador" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ryzen5">AMD Ryzen 5 5600X - R$ 1.299,90</SelectItem>
                        <SelectItem value="ryzen7">AMD Ryzen 7 5800X - R$ 1.899,90</SelectItem>
                        <SelectItem value="ryzen9">AMD Ryzen 9 5900X - R$ 2.699,90</SelectItem>
                        <SelectItem value="intel-i5">Intel Core i5 12600K - R$ 1.499,90</SelectItem>
                        <SelectItem value="intel-i7">Intel Core i7 12700K - R$ 2.199,90</SelectItem>
                        <SelectItem value="intel-i9">Intel Core i9 12900K - R$ 3.299,90</SelectItem>
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-purple-600"
                      >
                        <rect x="2" y="6" width="20" height="12" rx="2" />
                        <path d="M22 8.5h-2.5a1.5 1.5 0 0 0 0 3h1a1.5 1.5 0 0 1 0 3H18" />
                        <path d="M6 12h4" />
                        <path d="M18 12h.01" />
                      </svg>
                      <CardTitle>Placa de Vídeo</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Select
                      onValueChange={(value) => {
                        const gpus = {
                          rtx3060: { name: "NVIDIA RTX 3060 12GB", price: 2499.9 },
                          rtx3070: { name: "NVIDIA RTX 3070 8GB", price: 3999.9 },
                          rtx3080: { name: "NVIDIA RTX 3080 10GB", price: 5499.9 },
                          rx6600xt: { name: "AMD RX 6600 XT 8GB", price: 2299.9 },
                          rx6700xt: { name: "AMD RX 6700 XT 12GB", price: 3799.9 },
                          rx6800xt: { name: "AMD RX 6800 XT 16GB", price: 4999.9 },
                        }
                        handleComponentSelect("gpu", gpus[value as keyof typeof gpus])
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma placa de vídeo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="rtx3060">NVIDIA RTX 3060 12GB - R$ 2.499,90</SelectItem>
                        <SelectItem value="rtx3070">NVIDIA RTX 3070 8GB - R$ 3.999,90</SelectItem>
                        <SelectItem value="rtx3080">NVIDIA RTX 3080 10GB - R$ 5.499,90</SelectItem>
                        <SelectItem value="rx6600xt">AMD RX 6600 XT 8GB - R$ 2.299,90</SelectItem>
                        <SelectItem value="rx6700xt">AMD RX 6700 XT 12GB - R$ 3.799,90</SelectItem>
                        <SelectItem value="rx6800xt">AMD RX 6800 XT 16GB - R$ 4.999,90</SelectItem>
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-purple-600"
                      >
                        <path d="M8 19h8a4 4 0 0 0 4-4 7 7 0 0 0-7-7h-1a5 5 0 0 0-5 5v3a4 4 0 0 0 1 8Z" />
                        <path d="M12 19v3" />
                      </svg>
                      <CardTitle>Memória RAM</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Select
                      onValueChange={(value) => {
                        const rams = {
                          "8gb": { name: "8GB DDR4 3200MHz", price: 299.9 },
                          "16gb": { name: "16GB DDR4 3200MHz", price: 499.9 },
                          "32gb": { name: "32GB DDR4 3600MHz", price: 999.9 },
                          "64gb": { name: "64GB DDR4 3600MHz", price: 1999.9 },
                        }
                        handleComponentSelect("ram", rams[value as keyof typeof rams])
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a memória RAM" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="8gb">8GB DDR4 3200MHz - R$ 299,90</SelectItem>
                        <SelectItem value="16gb">16GB DDR4 3200MHz - R$ 499,90</SelectItem>
                        <SelectItem value="32gb">32GB DDR4 3600MHz - R$ 999,90</SelectItem>
                        <SelectItem value="64gb">64GB DDR4 3600MHz - R$ 1.999,90</SelectItem>
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <HardDrive className="h-5 w-5 text-purple-600" />
                      <CardTitle>Armazenamento</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Select
                      onValueChange={(value) => {
                        const storages = {
                          ssd256: { name: "SSD SATA 256GB", price: 199.9 },
                          ssd512: { name: "SSD NVMe 512GB", price: 399.9 },
                          ssd1tb: { name: "SSD NVMe 1TB", price: 699.9 },
                          ssd2tb: { name: "SSD NVMe 2TB", price: 1399.9 },
                        }
                        handleComponentSelect("storage", storages[value as keyof typeof storages])
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o armazenamento" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ssd256">SSD SATA 256GB - R$ 199,90</SelectItem>
                        <SelectItem value="ssd512">SSD NVMe 512GB - R$ 399,90</SelectItem>
                        <SelectItem value="ssd1tb">SSD NVMe 1TB - R$ 699,90</SelectItem>
                        <SelectItem value="ssd2tb">SSD NVMe 2TB - R$ 1.399,90</SelectItem>
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-purple-600"
                      >
                        <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
                      </svg>
                      <CardTitle>Fonte de Alimentação</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Select
                      onValueChange={(value) => {
                        const psus = {
                          "500w": { name: "500W 80 Plus Bronze", price: 299.9 },
                          "650w": { name: "650W 80 Plus Gold", price: 499.9 },
                          "750w": { name: "750W 80 Plus Gold", price: 699.9 },
                          "850w": { name: "850W 80 Plus Platinum", price: 999.9 },
                        }
                        handleComponentSelect("psu", psus[value as keyof typeof psus])
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a fonte" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="500w">500W 80 Plus Bronze - R$ 299,90</SelectItem>
                        <SelectItem value="650w">650W 80 Plus Gold - R$ 499,90</SelectItem>
                        <SelectItem value="750w">750W 80 Plus Gold - R$ 699,90</SelectItem>
                        <SelectItem value="850w">850W 80 Plus Platinum - R$ 999,90</SelectItem>
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Monitor className="h-5 w-5 text-purple-600" />
                      <CardTitle>Gabinete</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Select
                      onValueChange={(value) => {
                        const cases = {
                          basic: { name: "Gabinete Básico", price: 199.9 },
                          mid: { name: "Gabinete Mid-Tower", price: 399.9 },
                          premium: { name: "Gabinete Premium RGB", price: 699.9 },
                        }
                        handleComponentSelect("case", cases[value as keyof typeof cases])
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o gabinete" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Gabinete Básico - R$ 199,90</SelectItem>
                        <SelectItem value="mid">Gabinete Mid-Tower - R$ 399,90</SelectItem>
                        <SelectItem value="premium">Gabinete Premium RGB - R$ 699,90</SelectItem>
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <Card className="sticky top-8">
            <CardHeader>
              <CardTitle>Resumo do Pedido</CardTitle>
              <CardDescription>Componentes selecionados para seu PC</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(selectedComponents).length > 0 ? (
                  <>
                    {Object.entries(selectedComponents).map(([category, component]: [string, any]) => (
                      <div key={category} className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-green-500" />
                          <span className="capitalize">{category}</span>
                        </div>
                        <div className="text-right">
                          <div className="font-medium">{component.name}</div>
                          <div className="text-sm text-gray-600">R$ {component.price.toFixed(2)}</div>
                        </div>
                      </div>
                    ))}
                    <Separator />
                    <div className="flex justify-between font-bold">
                      <span>Total</span>
                      <span>R$ {totalPrice.toFixed(2)}</span>
                    </div>
                    <div className="text-sm text-gray-600">
                      Em até 12x de R$ {(totalPrice / 12).toFixed(2)} sem juros
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <p>Nenhum componente selecionado</p>
                    <p className="text-sm mt-2">Escolha os componentes para montar seu PC</p>
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-4">
              <Button
                className="w-full bg-purple-600 hover:bg-purple-700"
                disabled={Object.entries(selectedComponents).length === 0}
              >
                Finalizar Montagem
              </Button>
              <Button
                variant="outline"
                className="w-full border-purple-200 hover:bg-purple-50 hover:text-purple-700 bg-transparent"
                disabled={Object.entries(selectedComponents).length === 0}
              >
                Salvar Configuração
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>

      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-6">Perguntas Frequentes</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Como funciona o serviço de montagem?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Após finalizar a escolha dos componentes, nossa equipe técnica realizará a montagem completa do seu PC,
                incluindo instalação do sistema operacional e testes de desempenho. O prazo de montagem é de 3 a 5 dias
                úteis.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Os componentes têm garantia?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Sim, todos os componentes possuem garantia do fabricante, geralmente de 12 meses. Além disso, oferecemos
                3 meses de garantia adicional para o serviço de montagem.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Posso trocar componentes depois?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Sim, você pode solicitar upgrades ou trocas de componentes a qualquer momento. Nossa equipe técnica pode
                realizar a instalação dos novos componentes com segurança.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Como é feita a entrega?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                O PC montado é cuidadosamente embalado com proteção anti-impacto para garantir que chegue em perfeitas
                condições. A entrega é realizada por transportadora especializada em produtos frágeis.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
