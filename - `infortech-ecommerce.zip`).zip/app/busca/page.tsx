"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { useStore } from "@/lib/store"
import { searchProducts, brands, categories } from "@/lib/products"
import { ShoppingCart, Heart, Star, Filter, ArrowLeft } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

export default function BuscaPage() {
  const searchParams = useSearchParams()
  const query = searchParams.get("q") || ""

  const { addToCart, addToWishlist, removeFromWishlist, isInWishlist, filters, setFilters, resetFilters } = useStore()

  const [products, setProducts] = useState<any[]>([])
  const [sortBy, setSortBy] = useState("relevance")
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    setIsLoading(true)
    const results = searchProducts(query, filters)

    // Aplicar ordenação
    const sortedResults = [...results]
    switch (sortBy) {
      case "price-asc":
        sortedResults.sort((a, b) => a.price - b.price)
        break
      case "price-desc":
        sortedResults.sort((a, b) => b.price - a.price)
        break
      case "rating":
        sortedResults.sort((a, b) => b.rating - a.rating)
        break
      case "name":
        sortedResults.sort((a, b) => a.name.localeCompare(b.name))
        break
      default:
        // relevance - manter ordem original
        break
    }

    setProducts(sortedResults)
    setIsLoading(false)
  }, [query, filters, sortBy])

  const handleAddToCart = (product: any) => {
    addToCart(product)
    toast({
      title: "Produto adicionado!",
      description: `${product.name} foi adicionado ao carrinho.`,
    })
  }

  const handleWishlistToggle = (product: any) => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id)
      toast({
        title: "Removido da lista",
        description: `${product.name} foi removido da lista de desejos.`,
      })
    } else {
      addToWishlist(product)
      toast({
        title: "Adicionado à lista",
        description: `${product.name} foi adicionado à lista de desejos.`,
      })
    }
  }

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Categoria */}
      <div>
        <h3 className="font-medium mb-3">Categoria</h3>
        <div className="space-y-2">
          {categories.map((category) => (
            <div key={category.id} className="flex items-center space-x-2">
              <Checkbox
                id={category.id}
                checked={filters.category === category.id}
                onCheckedChange={(checked) => {
                  setFilters({ category: checked ? category.id : "" })
                }}
              />
              <Label htmlFor={category.id} className="text-sm">
                {category.name}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Marca */}
      <div>
        <h3 className="font-medium mb-3">Marca</h3>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {brands.map((brand) => (
            <div key={brand} className="flex items-center space-x-2">
              <Checkbox
                id={brand}
                checked={filters.brand === brand}
                onCheckedChange={(checked) => {
                  setFilters({ brand: checked ? brand : "" })
                }}
              />
              <Label htmlFor={brand} className="text-sm">
                {brand}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Preço */}
      <div>
        <h3 className="font-medium mb-3">Faixa de Preço</h3>
        <div className="px-2">
          <Slider
            value={filters.priceRange}
            onValueChange={(value) => setFilters({ priceRange: value as [number, number] })}
            max={10000}
            min={0}
            step={100}
            className="mb-4"
          />
          <div className="flex justify-between text-sm text-gray-600">
            <span>R$ {filters.priceRange[0]}</span>
            <span>R$ {filters.priceRange[1]}</span>
          </div>
        </div>
      </div>

      <Separator />

      {/* Avaliação */}
      <div>
        <h3 className="font-medium mb-3">Avaliação</h3>
        <div className="space-y-2">
          {[5, 4, 3, 2, 1].map((rating) => (
            <div key={rating} className="flex items-center space-x-2">
              <Checkbox
                id={`rating-${rating}`}
                checked={filters.rating === rating}
                onCheckedChange={(checked) => {
                  setFilters({ rating: checked ? rating : 0 })
                }}
              />
              <Label htmlFor={`rating-${rating}`} className="flex items-center text-sm">
                <div className="flex items-center mr-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-3 w-3 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                    />
                  ))}
                </div>
                {rating} estrela{rating !== 1 ? "s" : ""} ou mais
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      {/* Disponibilidade */}
      <div>
        <h3 className="font-medium mb-3">Disponibilidade</h3>
        <div className="flex items-center space-x-2">
          <Checkbox
            id="in-stock"
            checked={filters.inStock}
            onCheckedChange={(checked) => {
              setFilters({ inStock: checked as boolean })
            }}
          />
          <Label htmlFor="in-stock" className="text-sm">
            Apenas produtos em estoque
          </Label>
        </div>
      </div>

      <Button onClick={resetFilters} variant="outline" className="w-full bg-transparent">
        Limpar Filtros
      </Button>
    </div>
  )

  return (
    <div className="container py-8">
      <div className="mb-6">
        <Link href="/" className="flex items-center text-sm text-gray-600 hover:text-purple-600">
          <ArrowLeft className="h-4 w-4 mr-1" />
          Voltar para a página inicial
        </Link>
      </div>

      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">{query ? `Resultados para "${query}"` : "Todos os produtos"}</h1>
        <p className="text-gray-600">
          {isLoading
            ? "Carregando..."
            : `${products.length} produto${products.length !== 1 ? "s" : ""} encontrado${products.length !== 1 ? "s" : ""}`}
        </p>
      </div>

      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          {/* Mobile Filter */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="lg:hidden bg-transparent">
                <Filter className="h-4 w-4 mr-2" />
                Filtros
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <SheetHeader>
                <SheetTitle>Filtros</SheetTitle>
                <SheetDescription>Refine sua busca usando os filtros abaixo</SheetDescription>
              </SheetHeader>
              <div className="mt-6">
                <FilterContent />
              </div>
            </SheetContent>
          </Sheet>
        </div>

        {/* Ordenação */}
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Ordenar por" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="relevance">Relevância</SelectItem>
            <SelectItem value="price-asc">Menor preço</SelectItem>
            <SelectItem value="price-desc">Maior preço</SelectItem>
            <SelectItem value="rating">Melhor avaliação</SelectItem>
            <SelectItem value="name">Nome A-Z</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Desktop Filters */}
        <div className="hidden lg:block">
          <Card>
            <CardContent className="p-6">
              <h2 className="font-bold mb-4">Filtros</h2>
              <FilterContent />
            </CardContent>
          </Card>
        </div>

        {/* Products Grid */}
        <div className="lg:col-span-3">
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="aspect-square bg-gray-200 rounded-t-lg"></div>
                  <CardContent className="p-4">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-16">
              <h3 className="text-xl font-medium mb-2">Nenhum produto encontrado</h3>
              <p className="text-gray-600 mb-4">Tente ajustar os filtros ou fazer uma nova busca.</p>
              <Button onClick={resetFilters} variant="outline">
                Limpar Filtros
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <Card key={product.id} className="overflow-hidden border-0 shadow-md hover:shadow-lg transition-all">
                  <Link href={`/produto/${product.id}`}>
                    <div className="relative pt-4 px-4">
                      {product.oldPrice && (
                        <Badge className="absolute top-2 right-2 bg-purple-600 hover:bg-purple-700">
                          -{Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)}%
                        </Badge>
                      )}
                      <div className="aspect-square flex items-center justify-center bg-gray-50 rounded-lg overflow-hidden">
                        <img
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          className="object-contain h-full w-full p-4"
                        />
                      </div>
                    </div>
                  </Link>
                  <CardContent className="p-4">
                    <Link href={`/produto/${product.id}`} className="hover:text-purple-600">
                      <h3 className="font-medium line-clamp-2 h-12">{product.name}</h3>
                    </Link>
                    <div className="flex items-center gap-1 mt-2">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-3 w-3 ${
                              i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-gray-600">({product.reviews})</span>
                    </div>
                    <div className="mt-2">
                      {product.oldPrice && (
                        <div className="text-sm text-gray-500 line-through">R$ {product.oldPrice.toFixed(2)}</div>
                      )}
                      <div className="text-xl font-bold text-purple-600">R$ {product.price.toFixed(2)}</div>
                      <div className="text-sm text-gray-600">Em até 12x de R$ {(product.price / 12).toFixed(2)}</div>
                    </div>
                    {product.stock <= 5 && product.stock > 0 && (
                      <p className="text-sm text-orange-600 mt-2">Últimas {product.stock} unidades!</p>
                    )}
                    {product.stock === 0 && <p className="text-sm text-red-600 mt-2">Produto esgotado</p>}
                  </CardContent>
                  <CardFooter className="p-4 pt-0 flex gap-2">
                    <Button
                      className="flex-1 gap-2"
                      onClick={() => handleAddToCart(product)}
                      disabled={product.stock === 0}
                    >
                      <ShoppingCart className="h-4 w-4" />
                      {product.stock === 0 ? "Esgotado" : "Adicionar"}
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleWishlistToggle(product)}
                      className={isInWishlist(product.id) ? "text-red-600 border-red-200" : ""}
                    >
                      <Heart className={`h-4 w-4 ${isInWishlist(product.id) ? "fill-red-600" : ""}`} />
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
