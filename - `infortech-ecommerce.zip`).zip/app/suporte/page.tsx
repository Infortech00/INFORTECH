import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageSquare, Mail, Phone, FileText, HelpCircle, Settings, Wrench, Monitor, Cpu, Laptop } from "lucide-react"

export default function SupportPage() {
  return (
    <div className="container py-8">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl font-bold mb-4">Central de Suporte</h1>
        <p className="text-gray-600 mb-8">
          Estamos aqui para ajudar você com qualquer dúvida ou problema técnico. Escolha uma das opções abaixo para
          começar.
        </p>
      </div>

      <Tabs defaultValue="contact" className="max-w-5xl mx-auto">
        <TabsList className="grid grid-cols-3 mb-8">
          <TabsTrigger value="contact" className="py-3">
            <div className="flex flex-col items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              <span>Contato</span>
            </div>
          </TabsTrigger>
          <TabsTrigger value="faq" className="py-3">
            <div className="flex flex-col items-center gap-2">
              <HelpCircle className="h-5 w-5" />
              <span>Perguntas Frequentes</span>
            </div>
          </TabsTrigger>
          <TabsTrigger value="technical" className="py-3">
            <div className="flex flex-col items-center gap-2">
              <Settings className="h-5 w-5" />
              <span>Suporte Técnico</span>
            </div>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="contact">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Formulário de Contato</CardTitle>
                <CardDescription>
                  Preencha o formulário abaixo e entraremos em contato o mais breve possível.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">
                        Nome
                      </label>
                      <Input id="name" placeholder="Seu nome completo" />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email
                      </label>
                      <Input id="email" type="email" placeholder="seu@email.com" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="subject" className="text-sm font-medium">
                      Assunto
                    </label>
                    <Input id="subject" placeholder="Assunto da mensagem" />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="department" className="text-sm font-medium">
                      Departamento
                    </label>
                    <Select>
                      <SelectTrigger id="department">
                        <SelectValue placeholder="Selecione um departamento" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="technical">Suporte Técnico</SelectItem>
                        <SelectItem value="sales">Vendas</SelectItem>
                        <SelectItem value="warranty">Garantia</SelectItem>
                        <SelectItem value="returns">Devoluções</SelectItem>
                        <SelectItem value="other">Outros</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium">
                      Mensagem
                    </label>
                    <Textarea id="message" placeholder="Descreva sua dúvida ou problema em detalhes" rows={5} />
                  </div>
                </form>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Enviar Mensagem</Button>
              </CardFooter>
            </Card>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Informações de Contato</CardTitle>
                  <CardDescription>Entre em contato conosco através dos canais abaixo.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                        <Phone className="h-5 w-5 text-purple-600" />
                      </div>
                      <div>
                        <div className="font-medium">Telefone</div>
                        <div className="text-gray-600">(11) 9999-9999</div>
                        <div className="text-sm text-gray-500">Seg-Sex: 9h às 18h</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                        <Mail className="h-5 w-5 text-purple-600" />
                      </div>
                      <div>
                        <div className="font-medium">Email</div>
                        <div className="text-gray-600">suporte@infortech.com.br</div>
                        <div className="text-sm text-gray-500">Resposta em até 24h</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                        <MessageSquare className="h-5 w-5 text-purple-600" />
                      </div>
                      <div>
                        <div className="font-medium">Chat Online</div>
                        <div className="text-gray-600">Chat ao vivo no site</div>
                        <div className="text-sm text-gray-500">Seg-Sex: 9h às 18h</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Horário de Atendimento</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Segunda a Sexta</span>
                      <span className="font-medium">9h às 18h</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sábado</span>
                      <span className="font-medium">10h às 14h</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Domingo e Feriados</span>
                      <span className="font-medium">Fechado</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="faq">
          <Card>
            <CardHeader>
              <CardTitle>Perguntas Frequentes</CardTitle>
              <CardDescription>Encontre respostas para as dúvidas mais comuns dos nossos clientes.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Como faço para rastrear meu pedido?</h3>
                  <p className="text-gray-600">
                    Você pode rastrear seu pedido fazendo login na sua conta e acessando a seção "Meus Pedidos". Lá você
                    encontrará o código de rastreamento e um link direto para o site da transportadora.
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Qual é o prazo de entrega?</h3>
                  <p className="text-gray-600">
                    O prazo de entrega varia de acordo com a sua localização. Geralmente, entregamos em capitais e
                    regiões metropolitanas em 1-3 dias úteis. Para outras localidades, o prazo pode ser de 3-7 dias
                    úteis. O prazo exato é informado durante o checkout.
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Como funciona a garantia dos produtos?</h3>
                  <p className="text-gray-600">
                    Todos os nossos produtos possuem garantia mínima de 12 meses, sendo 3 meses de garantia legal e 9
                    meses de garantia contratual. Alguns produtos podem ter garantia estendida oferecida pelo
                    fabricante. As informações específicas de garantia estão disponíveis na página de cada produto.
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Como solicitar a troca ou devolução de um produto?</h3>
                  <p className="text-gray-600">
                    Para solicitar uma troca ou devolução, acesse sua conta, vá até "Meus Pedidos", selecione o pedido
                    desejado e clique em "Solicitar Troca/Devolução". Você tem até 7 dias após o recebimento para
                    devolver um produto sem justificativa, conforme o Código de Defesa do Consumidor.
                  </p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Quais são as formas de pagamento aceitas?</h3>
                  <p className="text-gray-600">
                    Aceitamos cartões de crédito (parcelamento em até 12x sem juros), cartões de débito, boleto
                    bancário, PIX e transferência bancária. Para pagamentos via boleto ou PIX, oferecemos 10% de
                    desconto no valor total da compra.
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <p className="text-sm text-gray-600">Não encontrou o que procurava?</p>
              <Button
                variant="outline"
                className="border-purple-200 hover:bg-purple-50 hover:text-purple-700 bg-transparent"
              >
                Ver todas as perguntas
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="technical">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="overflow-hidden">
              <CardHeader className="bg-purple-600 text-white">
                <div className="flex items-center gap-2">
                  <Wrench className="h-5 w-5" />
                  <CardTitle className="text-white">Manutenção</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <p className="text-gray-600">
                    Serviços de manutenção para computadores, notebooks e equipamentos de rede.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Formatação e instalação de sistemas</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Limpeza e manutenção preventiva</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Reparo de hardware</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Recuperação de dados</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Solicitar Serviço</Button>
              </CardFooter>
            </Card>

            <Card className="overflow-hidden">
              <CardHeader className="bg-gray-800 text-white">
                <div className="flex items-center gap-2">
                  <Cpu className="h-5 w-5" />
                  <CardTitle className="text-white">Montagem de PCs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <p className="text-gray-600">Serviços especializados de montagem e configuração de computadores.</p>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Montagem de PCs personalizados</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Upgrade de componentes</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Configuração para overclock</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Instalação de watercooling</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-gray-800 hover:bg-gray-700">Solicitar Orçamento</Button>
              </CardFooter>
            </Card>

            <Card className="overflow-hidden">
              <CardHeader className="bg-purple-800 text-white">
                <div className="flex items-center gap-2">
                  <Monitor className="h-5 w-5" />
                  <CardTitle className="text-white">Desenvolvimento Web</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <p className="text-gray-600">
                    Serviços de desenvolvimento de sites e aplicações web para sua empresa.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Criação de sites institucionais</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Lojas virtuais e e-commerce</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Sistemas web personalizados</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-purple-600 mt-2"></div>
                      <span className="text-sm">Manutenção e suporte de sites</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-purple-800 hover:bg-purple-700">Solicitar Projeto</Button>
              </CardFooter>
            </Card>
          </div>

          <div className="mt-8 bg-gray-50 p-6 rounded-lg">
            <div className="text-center mb-6">
              <h3 className="text-xl font-bold">Precisa de suporte técnico especializado?</h3>
              <p className="text-gray-600">
                Nossa equipe de técnicos certificados está pronta para ajudar com qualquer problema.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h4 className="font-medium mb-4 flex items-center gap-2">
                  <Laptop className="h-5 w-5 text-purple-600" />
                  Suporte Remoto
                </h4>
                <p className="text-gray-600 mb-4">
                  Resolva problemas rapidamente com nossa assistência remota. Nossos técnicos podem acessar seu
                  computador e resolver problemas sem a necessidade de visita técnica.
                </p>
                <Button
                  variant="outline"
                  className="w-full border-purple-200 hover:bg-purple-50 hover:text-purple-700 bg-transparent"
                >
                  Solicitar Suporte Remoto
                </Button>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h4 className="font-medium mb-4 flex items-center gap-2">
                  <FileText className="h-5 w-5 text-purple-600" />
                  Documentação Técnica
                </h4>
                <p className="text-gray-600 mb-4">
                  Acesse nossa base de conhecimento com tutoriais, guias e documentação técnica para resolver problemas
                  comuns por conta própria.
                </p>
                <Button
                  variant="outline"
                  className="w-full border-purple-200 hover:bg-purple-50 hover:text-purple-700 bg-transparent"
                >
                  Acessar Base de Conhecimento
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
