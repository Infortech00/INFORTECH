"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useStore } from "@/lib/store"
import { getProductsByCategory, categories } from "@/lib/products"
import { ShoppingCart, Heart, Star, ArrowLeft } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function CategoriaPage({ params }: { params: { slug: string } }) {
  const [products, setProducts] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { addToCart, addToWishlist, removeFromWishlist, isInWishlist } = useStore()
  const { toast } = useToast()

  const category = categories.find((cat) => cat.id === params.slug)
  const categoryName = category?.name || params.slug

  useEffect(() => {
    setIsLoading(true)
    const categoryProducts = getProductsByCategory(params.slug)
    setProducts(categoryProducts)
    setIsLoading(false)
  }, [params.slug])

  const handleAddToCart = (product: any) => {
    addToCart(product)
    toast({
      title: "Produto adicionado!",
      description: `${product.name} foi adicionado ao carrinho.`,
    })
  }

  const handleWishlistToggle = (product: any) => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id)
      toast({
        title: "Removido da lista",
        description: `${product.name} foi removido da lista de desejos.`,
      })
    } else {
      addToWishlist(product)
      toast({
        title: "Adicionado à lista",
        description: `${product.name} foi adicionado à lista de desejos.`,
      })
    }
  }

  return (
    <div className="container py-8">
      <div className="mb-6">
        <Link href="/" className="flex items-center text-sm text-gray-600 hover:text-purple-600">
          <ArrowLeft className="h-4 w-4 mr-1" />
          Voltar para a página inicial
        </Link>
      </div>

      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">{categoryName}</h1>
        <p className="text-gray-600">
          {isLoading
            ? "Carregando..."
            : `${products.length} produto${products.length !== 1 ? "s" : ""} encontrado${products.length !== 1 ? "s" : ""}`}
        </p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <div className="aspect-square bg-gray-200 rounded-t-lg"></div>
              <CardContent className="p-4">
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-2/3"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-16">
          <h3 className="text-xl font-medium mb-2">Nenhum produto encontrado</h3>
          <p className="text-gray-600 mb-4">Esta categoria ainda não possui produtos cadastrados.</p>
          <Button asChild>
            <Link href="/produtos">Ver todos os produtos</Link>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="overflow-hidden border-0 shadow-md hover:shadow-lg transition-all">
              <Link href={`/produto/${product.id}`}>
                <div className="relative pt-4 px-4">
                  {product.oldPrice && (
                    <Badge className="absolute top-2 right-2 bg-purple-600 hover:bg-purple-700">
                      -{Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)}%
                    </Badge>
                  )}
                  <div className="aspect-square flex items-center justify-center bg-gray-50 rounded-lg overflow-hidden">
                    <img
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      className="object-contain h-full w-full p-4"
                    />
                  </div>
                </div>
              </Link>
              <CardContent className="p-4">
                <Link href={`/produto/${product.id}`} className="hover:text-purple-600">
                  <h3 className="font-medium line-clamp-2 h-12">{product.name}</h3>
                </Link>
                <div className="flex items-center gap-1 mt-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-3 w-3 ${
                          i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-gray-600">({product.reviews})</span>
                </div>
                <div className="mt-2">
                  {product.oldPrice && (
                    <div className="text-sm text-gray-500 line-through">R$ {product.oldPrice.toFixed(2)}</div>
                  )}
                  <div className="text-xl font-bold text-purple-600">R$ {product.price.toFixed(2)}</div>
                  <div className="text-sm text-gray-600">Em até 12x de R$ {(product.price / 12).toFixed(2)}</div>
                </div>
                {product.stock <= 5 && product.stock > 0 && (
                  <p className="text-sm text-orange-600 mt-2">Últimas {product.stock} unidades!</p>
                )}
                {product.stock === 0 && <p className="text-sm text-red-600 mt-2">Produto esgotado</p>}
              </CardContent>
              <CardFooter className="p-4 pt-0 flex gap-2">
                <Button
                  className="flex-1 gap-2"
                  onClick={() => handleAddToCart(product)}
                  disabled={product.stock === 0}
                >
                  <ShoppingCart className="h-4 w-4" />
                  {product.stock === 0 ? "Esgotado" : "Adicionar"}
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleWishlistToggle(product)}
                  className={isInWishlist(product.id) ? "text-red-600 border-red-200" : ""}
                >
                  <Heart className={`h-4 w-4 ${isInWishlist(product.id) ? "fill-red-600" : ""}`} />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
