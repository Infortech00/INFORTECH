import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

const categories = [
  {
    id: 1,
    name: "Processadores",
    icon: "cpu",
    link: "/categoria/processadores",
    image: "/placeholder-smsyy.png",
  },
  {
    id: 2,
    name: "Placas de Vídeo",
    icon: "gpu",
    link: "/categoria/placas-video",
    image: "/graphics-card-gpu.png",
  },
  {
    id: 3,
    name: "Memória RAM",
    icon: "memory",
    link: "/categoria/memoria-ram",
    image: "/ram-memory-stick.png",
  },
  {
    id: 4,
    name: "Armazenamento",
    icon: "hard-drive",
    link: "/categoria/armazenamento",
    image: "/placeholder-0n39i.png",
  },
  {
    id: 5,
    name: "Monitores",
    icon: "monitor",
    link: "/categoria/monitores",
    image: "/computer-monitor-display.png",
  },
  {
    id: 6,
    name: "Periféricos",
    icon: "keyboard",
    link: "/categoria/perifericos",
    image: "/placeholder-17l8t.png",
  },
  {
    id: 7,
    name: "Cadeiras",
    icon: "chair",
    link: "/categoria/cadeiras",
    image: "/ergonomic-gaming-chair.png",
  },
  {
    id: 8,
    name: "Notebooks",
    icon: "laptop",
    link: "/categoria/notebooks",
    image: "/gaming-laptop.png",
  },
]

export default function CategoryGrid() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
      {categories.map((category) => (
        <Link key={category.id} href={category.link}>
          <Card className="overflow-hidden border-0 shadow-md hover:shadow-lg transition-shadow">
            <CardContent className="p-0">
              <div className="aspect-square relative">
                <div
                  className="absolute inset-0 bg-cover bg-center"
                  style={{ backgroundImage: `url(${category.image})` }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
                  <h3 className="text-white font-medium">{category.name}</h3>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}
