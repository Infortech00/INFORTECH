"use client"

import { useState, useRef } from "react"
import Link from "next/link"
import { ChevronLeft, ChevronRight, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { cn } from "@/lib/utils"

const products = {
  hardware: [
    {
      id: 1,
      name: "Processador Intel Core i7-12700K",
      price: 2499.9,
      image: "/intel-core-i7.png",
      link: "/produto/processador-intel-core-i7-12700k",
    },
    {
      id: 2,
      name: "Placa-Mãe ASUS ROG Strix Z690-F",
      price: 1899.9,
      image: "/asus-rog-motherboard.png",
      link: "/produto/placa-mae-asus-rog-strix-z690f",
    },
    {
      id: 3,
      name: "Memória RAM Corsair Vengeance 32GB DDR5",
      price: 1299.9,
      image: "/placeholder-duh3t.png",
      link: "/produto/memoria-ram-corsair-vengeance-32gb-ddr5",
    },
    {
      id: 4,
      name: "SSD NVMe Samsung 980 Pro 1TB",
      price: 899.9,
      image: "/placeholder-ju707.png",
      link: "/produto/ssd-nvme-samsung-980-pro-1tb",
    },
    {
      id: 5,
      name: "Placa de Vídeo ASUS TUF RTX 3080 10GB",
      price: 5499.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/placa-video-asus-tuf-rtx-3080",
    },
    {
      id: 6,
      name: "Fonte Corsair RM850x 850W 80 Plus Gold",
      price: 799.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/fonte-corsair-rm850x",
    },
  ],
  perifericos: [
    {
      id: 1,
      name: "Teclado Mecânico Logitech G Pro X",
      price: 899.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/teclado-mecanico-logitech-g-pro-x",
    },
    {
      id: 2,
      name: "Mouse Gamer Razer DeathAdder V2 Pro",
      price: 599.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/mouse-gamer-razer-deathadder-v2-pro",
    },
    {
      id: 3,
      name: "Headset HyperX Cloud Alpha",
      price: 499.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/headset-hyperx-cloud-alpha",
    },
    {
      id: 4,
      name: "Mousepad Steelseries QcK Edge XL",
      price: 199.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/mousepad-steelseries-qck-edge-xl",
    },
    {
      id: 5,
      name: "Webcam Logitech C922 Pro Stream",
      price: 499.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/webcam-logitech-c922-pro-stream",
    },
    {
      id: 6,
      name: "Microfone HyperX QuadCast S",
      price: 899.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/microfone-hyperx-quadcast-s",
    },
  ],
  monitores: [
    {
      id: 1,
      name: 'Monitor LG UltraGear 27" 240Hz IPS',
      price: 2499.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/monitor-lg-ultragear-27-240hz",
    },
    {
      id: 2,
      name: 'Monitor Samsung Odyssey G7 32" 240Hz',
      price: 3499.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/monitor-samsung-odyssey-g7-32",
    },
    {
      id: 3,
      name: 'Monitor Dell S2722DGM 27" 165Hz',
      price: 1999.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/monitor-dell-s2722dgm-27",
    },
    {
      id: 4,
      name: 'Monitor ASUS TUF Gaming VG27AQ 27" 165Hz',
      price: 2299.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/monitor-asus-tuf-gaming-vg27aq",
    },
    {
      id: 5,
      name: 'Monitor Ultrawide LG 34" 144Hz',
      price: 2999.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/monitor-ultrawide-lg-34-144hz",
    },
    {
      id: 6,
      name: 'Monitor Profissional BenQ PD2700U 27" 4K',
      price: 3299.9,
      image: "/placeholder.svg?height=200&width=200",
      link: "/produto/monitor-profissional-benq-pd2700u",
    },
  ],
}

export default function ProductCarousel({ category }: { category: "hardware" | "perifericos" | "monitores" }) {
  const [scrollPosition, setScrollPosition] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (containerRef.current) {
      const container = containerRef.current
      const scrollAmount = container.clientWidth * 0.8

      if (direction === "left") {
        container.scrollBy({ left: -scrollAmount, behavior: "smooth" })
        setScrollPosition(Math.max(0, scrollPosition - scrollAmount))
      } else {
        container.scrollBy({ left: scrollAmount, behavior: "smooth" })
        setScrollPosition(Math.min(container.scrollWidth - container.clientWidth, scrollPosition + scrollAmount))
      }
    }
  }

  const categoryProducts = products[category] || []

  return (
    <div className="relative">
      <div className="absolute -left-4 top-1/2 -translate-y-1/2 z-10">
        <Button
          variant="outline"
          size="icon"
          className="rounded-full shadow-md bg-white"
          onClick={() => scroll("left")}
          disabled={scrollPosition <= 0}
        >
          <ChevronLeft className="h-5 w-5" />
          <span className="sr-only">Anterior</span>
        </Button>
      </div>
      <div
        ref={containerRef}
        className="flex gap-4 overflow-x-auto scrollbar-hide pb-4 px-1"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {categoryProducts.map((product) => (
          <Card
            key={product.id}
            className={cn("flex-shrink-0 w-[250px] border-0 shadow-md hover:shadow-lg transition-all")}
          >
            <Link href={product.link}>
              <div className="p-4">
                <div className="aspect-square flex items-center justify-center bg-gray-50 rounded-lg overflow-hidden">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="object-contain h-full w-full p-4"
                  />
                </div>
              </div>
            </Link>
            <CardContent className="p-4 pt-0">
              <Link href={product.link} className="hover:text-purple-600">
                <h3 className="font-medium line-clamp-2 h-12">{product.name}</h3>
              </Link>
              <div className="mt-2">
                <div className="text-lg font-bold text-purple-600">R$ {product.price.toFixed(2)}</div>
                <div className="text-sm text-gray-600">Em até 12x de R$ {(product.price / 12).toFixed(2)}</div>
              </div>
            </CardContent>
            <CardFooter className="p-4 pt-0">
              <Button
                variant="outline"
                className="w-full gap-2 border-purple-200 hover:bg-purple-50 hover:text-purple-700 bg-transparent"
              >
                <ShoppingCart className="h-4 w-4" />
                Adicionar
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      <div className="absolute -right-4 top-1/2 -translate-y-1/2 z-10">
        <Button
          variant="outline"
          size="icon"
          className="rounded-full shadow-md bg-white"
          onClick={() => scroll("right")}
          disabled={
            containerRef.current
              ? scrollPosition >= containerRef.current.scrollWidth - containerRef.current.clientWidth
              : false
          }
        >
          <ChevronRight className="h-5 w-5" />
          <span className="sr-only">Próximo</span>
        </Button>
      </div>
    </div>
  )
}
