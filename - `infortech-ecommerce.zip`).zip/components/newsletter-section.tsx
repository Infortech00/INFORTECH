"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"

export default function NewsletterSection() {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simular envio
    await new Promise((resolve) => setTimeout(resolve, 1000))

    toast({
      title: "Inscrição realizada!",
      description: "Você receberá nossas ofertas exclusivas em seu email.",
    })

    setEmail("")
    setIsLoading(false)
  }

  return (
    <section className="py-8 bg-purple-900 text-white">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">Serviços Especializados</h2>
            <p className="mb-6">
              Nossa equipe de especialistas oferece serviços de manutenção, montagem de computadores e desenvolvimento
              de sites personalizados para sua empresa.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button variant="secondary" asChild>
                <a href="/servicos/manutencao">Manutenção</a>
              </Button>
              <Button
                variant="outline"
                className="bg-transparent text-white border-white hover:bg-white hover:text-purple-900"
                asChild
              >
                <a href="/servicos/sites">Desenvolvimento Web</a>
              </Button>
            </div>
          </div>
          <div className="bg-white/10 p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-4">Newsletter</h3>
            <p className="mb-4 text-sm">Receba ofertas exclusivas e novidades em primeira mão!</p>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="email"
                placeholder="Seu melhor email"
                className="bg-white/20 border-0 text-white placeholder:text-white/70"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Button type="submit" className="w-full bg-white text-purple-900 hover:bg-gray-100" disabled={isLoading}>
                {isLoading ? "Enviando..." : "Inscrever-se"}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
