import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { ShoppingCart } from "lucide-react"

const featuredProducts = [
  {
    id: 1,
    name: "Processador AMD Ryzen 7 5800X",
    price: 1899.9,
    oldPrice: 2299.9,
    image: "/amd-ryzen-processor.png",
    discount: 17,
    link: "/produto/processador-amd-ryzen-7-5800x",
  },
  {
    id: 2,
    name: "Placa de Vídeo NVIDIA RTX 4060 8GB",
    price: 2499.9,
    oldPrice: 2799.9,
    image: "/nvidia-rtx-graphics-card.png",
    discount: 11,
    link: "/produto/placa-video-nvidia-rtx-4060",
  },
  {
    id: 3,
    name: 'Monitor Gamer 27" 165Hz IPS',
    price: 1599.9,
    oldPrice: 1899.9,
    image: "/gaming-monitor-display.png",
    discount: 16,
    link: "/produto/monitor-gamer-27-165hz",
  },
  {
    id: 4,
    name: "Cadeira Gamer Ergonômica",
    price: 899.9,
    oldPrice: 1199.9,
    image: "/ergonomic-gaming-chair.png",
    discount: 25,
    link: "/produto/cadeira-gamer-ergonomica",
  },
]

export default function FeaturedProducts() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {featuredProducts.map((product) => (
        <Card key={product.id} className="overflow-hidden border-0 shadow-md hover:shadow-lg transition-all">
          <Link href={product.link}>
            <div className="relative pt-4 px-4">
              <Badge className="absolute top-2 right-2 bg-purple-600 hover:bg-purple-700">-{product.discount}%</Badge>
              <div className="aspect-square flex items-center justify-center bg-gray-50 rounded-lg overflow-hidden">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="object-contain h-full w-full p-4"
                />
              </div>
            </div>
          </Link>
          <CardContent className="p-4">
            <Link href={product.link} className="hover:text-purple-600">
              <h3 className="font-medium line-clamp-2 h-12">{product.name}</h3>
            </Link>
            <div className="mt-2">
              <div className="text-sm text-gray-500 line-through">R$ {product.oldPrice.toFixed(2)}</div>
              <div className="text-xl font-bold text-purple-600">R$ {product.price.toFixed(2)}</div>
              <div className="text-sm text-gray-600">Em até 12x de R$ {(product.price / 12).toFixed(2)}</div>
            </div>
          </CardContent>
          <CardFooter className="p-4 pt-0">
            <Button className="w-full gap-2">
              <ShoppingCart className="h-4 w-4" />
              Adicionar
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
