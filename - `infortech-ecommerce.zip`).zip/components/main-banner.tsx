"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const banners = [
  {
    id: 1,
    title: "Promoção de Placas de Vídeo",
    description: "Até 30% de desconto em placas de vídeo selecionadas",
    image: "/purple-gaming-setup.png",
    bgColor: "from-purple-700 to-purple-500",
    link: "/promocao/placas-video",
  },
  {
    id: 2,
    title: "Monte seu PC Gamer",
    description: "Escolha os componentes ideais para seu setup",
    image: "/custom-pc-rgb.png",
    bgColor: "from-gray-800 to-gray-600",
    link: "/monte-seu-pc",
  },
  {
    id: 3,
    title: "Serviços de Manutenção",
    description: "Manutenção especializada para seu equipamento",
    image: "/computer-repair-technician.png",
    bgColor: "from-purple-900 to-purple-700",
    link: "/servicos/manutencao",
  },
]

export default function MainBanner() {
  const [currentBanner, setCurrentBanner] = useState(0)

  const nextBanner = () => {
    setCurrentBanner((prev) => (prev + 1) % banners.length)
  }

  const prevBanner = () => {
    setCurrentBanner((prev) => (prev - 1 + banners.length) % banners.length)
  }

  useEffect(() => {
    const interval = setInterval(() => {
      nextBanner()
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative overflow-hidden rounded-xl h-[400px] shadow-xl">
      {banners.map((banner, index) => (
        <div
          key={banner.id}
          className={cn(
            "absolute inset-0 transition-all duration-500 ease-in-out",
            index === currentBanner ? "opacity-100 z-10" : "opacity-0 z-0",
          )}
        >
          <div className={`absolute inset-0 bg-gradient-to-r ${banner.bgColor} opacity-80`} />
          <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${banner.image})` }} />
          <div className="absolute inset-0 flex items-center">
            <div className="container">
              <div className="max-w-lg text-white p-6 bg-black/30 backdrop-blur-sm rounded-lg">
                <h2 className="text-3xl font-bold mb-2">{banner.title}</h2>
                <p className="mb-4 text-lg">{banner.description}</p>
                <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                  Ver ofertas
                </Button>
              </div>
            </div>
          </div>
        </div>
      ))}
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-2 top-1/2 -translate-y-1/2 z-20 bg-black/20 hover:bg-black/40 text-white rounded-full h-10 w-10"
        onClick={prevBanner}
      >
        <ChevronLeft className="h-6 w-6" />
        <span className="sr-only">Anterior</span>
      </Button>
      <Button
        variant="ghost"
        size="icon"
        className="absolute right-2 top-1/2 -translate-y-1/2 z-20 bg-black/20 hover:bg-black/40 text-white rounded-full h-10 w-10"
        onClick={nextBanner}
      >
        <ChevronRight className="h-6 w-6" />
        <span className="sr-only">Próximo</span>
      </Button>
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {banners.map((_, index) => (
          <button
            key={index}
            className={cn(
              "w-2 h-2 rounded-full transition-all",
              index === currentBanner ? "bg-white w-6" : "bg-white/50",
            )}
            onClick={() => setCurrentBanner(index)}
          />
        ))}
      </div>
    </div>
  )
}
