"use client"

import type React from "react"

import Link from "next/link"
import { useState } from "react"
import { Search, ShoppingCart, User, Heart, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { useStore } from "@/lib/store"
import { searchProducts } from "@/lib/products"
import { useRouter } from "next/navigation"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const router = useRouter()

  const { searchQuery, setSearchQuery, setSearchResults, getCartItemsCount, wishlist, user, logout } = useStore()

  const cartItemsCount = getCartItemsCount()
  const wishlistCount = wishlist.length

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      const results = searchProducts(searchQuery)
      setSearchResults(results)
      router.push(`/busca?q=${encodeURIComponent(searchQuery)}`)
    }
  }

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background">
      <div className="container flex items-center justify-between h-16 py-4">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-purple-400 text-transparent bg-clip-text">
              InfoTech
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex gap-6">
            <Link href="/produtos" className="text-sm font-medium transition-colors hover:text-purple-600">
              Produtos
            </Link>
            <Link href="/monte-seu-pc" className="text-sm font-medium transition-colors hover:text-purple-600">
              Monte seu PC
            </Link>
            <Link href="/manutencao" className="text-sm font-medium transition-colors hover:text-purple-600">
              Manutenção
            </Link>
            <Link href="/sites" className="text-sm font-medium transition-colors hover:text-purple-600">
              Criação de Sites
            </Link>
            <Link href="/suporte" className="text-sm font-medium transition-colors hover:text-purple-600">
              Suporte
            </Link>
          </nav>
        </div>

        <div className="flex items-center gap-4">
          {/* Search Bar */}
          <form onSubmit={handleSearch} className="relative w-full max-w-sm hidden md:block">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Pesquisar produtos..."
              className="pl-8 w-[300px] bg-gray-100"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </form>

          {/* User Menu */}
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                  <span className="sr-only">Conta</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href="/conta">Minha Conta</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/conta/pedidos">Meus Pedidos</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/conta/enderecos">Endereços</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>Sair</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button variant="ghost" size="icon" asChild>
              <Link href="/login">
                <User className="h-5 w-5" />
                <span className="sr-only">Login</span>
              </Link>
            </Button>
          )}

          {/* Wishlist */}
          <Button variant="ghost" size="icon" asChild className="relative">
            <Link href="/lista-desejos">
              <Heart className="h-5 w-5" />
              {wishlistCount > 0 && (
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-purple-600">
                  {wishlistCount}
                </Badge>
              )}
              <span className="sr-only">Lista de desejos</span>
            </Link>
          </Button>

          {/* Cart */}
          <Button variant="ghost" size="icon" asChild className="relative">
            <Link href="/carrinho">
              <ShoppingCart className="h-5 w-5" />
              {cartItemsCount > 0 && (
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-purple-600">
                  {cartItemsCount}
                </Badge>
              )}
              <span className="sr-only">Carrinho</span>
            </Link>
          </Button>

          {/* Mobile Menu */}
          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <SheetHeader>
                <SheetTitle>Menu</SheetTitle>
              </SheetHeader>
              <div className="flex flex-col gap-4 mt-6">
                {/* Mobile Search */}
                <form onSubmit={handleSearch} className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Pesquisar produtos..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </form>

                {/* Mobile Navigation */}
                <nav className="flex flex-col gap-4">
                  <Link
                    href="/produtos"
                    className="text-sm font-medium transition-colors hover:text-purple-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Produtos
                  </Link>
                  <Link
                    href="/monte-seu-pc"
                    className="text-sm font-medium transition-colors hover:text-purple-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Monte seu PC
                  </Link>
                  <Link
                    href="/manutencao"
                    className="text-sm font-medium transition-colors hover:text-purple-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Manutenção
                  </Link>
                  <Link
                    href="/sites"
                    className="text-sm font-medium transition-colors hover:text-purple-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Criação de Sites
                  </Link>
                  <Link
                    href="/suporte"
                    className="text-sm font-medium transition-colors hover:text-purple-600"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Suporte
                  </Link>
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Categories Bar */}
      <div className="container py-2 border-t">
        <nav className="flex items-center gap-4 text-sm overflow-x-auto pb-2">
          <Link href="/categoria/processadores" className="whitespace-nowrap hover:text-purple-600">
            Processadores
          </Link>
          <Link href="/categoria/placas-video" className="whitespace-nowrap hover:text-purple-600">
            Placas de Vídeo
          </Link>
          <Link href="/categoria/memoria-ram" className="whitespace-nowrap hover:text-purple-600">
            Memória RAM
          </Link>
          <Link href="/categoria/armazenamento" className="whitespace-nowrap hover:text-purple-600">
            Armazenamento
          </Link>
          <Link href="/categoria/monitores" className="whitespace-nowrap hover:text-purple-600">
            Monitores
          </Link>
          <Link href="/categoria/perifericos" className="whitespace-nowrap hover:text-purple-600">
            Periféricos
          </Link>
          <Link href="/categoria/cadeiras" className="whitespace-nowrap hover:text-purple-600">
            Cadeiras Gamer
          </Link>
          <Link href="/categoria/notebooks" className="whitespace-nowrap hover:text-purple-600">
            Notebooks
          </Link>
        </nav>
      </div>
    </header>
  )
}
