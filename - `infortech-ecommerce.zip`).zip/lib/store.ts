"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface Product {
  id: number
  name: string
  price: number
  oldPrice?: number
  image: string
  category: string
  brand: string
  rating: number
  reviews: number
  stock: number
  description: string
  specifications: Record<string, string>
  features: string[]
}

export interface CartItem extends Product {
  quantity: number
}

export interface User {
  id: number
  name: string
  email: string
  phone?: string
  addresses: Address[]
  orders: Order[]
}

export interface Address {
  id: number
  name: string
  street: string
  number: string
  complement?: string
  neighborhood: string
  city: string
  state: string
  zipCode: string
  isDefault: boolean
}

export interface Order {
  id: number
  date: string
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled"
  total: number
  items: CartItem[]
  address: Address
  trackingCode?: string
}

interface Store {
  // Cart
  cart: CartItem[]
  addToCart: (product: Product, quantity?: number) => void
  removeFromCart: (productId: number) => void
  updateQuantity: (productId: number, quantity: number) => void
  clearCart: () => void
  getCartTotal: () => number
  getCartItemsCount: () => number

  // User
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  register: (userData: Partial<User>) => Promise<boolean>
  updateUser: (userData: Partial<User>) => void

  // Wishlist
  wishlist: Product[]
  addToWishlist: (product: Product) => void
  removeFromWishlist: (productId: number) => void
  isInWishlist: (productId: number) => boolean

  // Search
  searchQuery: string
  setSearchQuery: (query: string) => void
  searchResults: Product[]
  setSearchResults: (results: Product[]) => void

  // Filters
  filters: {
    category: string
    priceRange: [number, number]
    brand: string
    rating: number
    inStock: boolean
  }
  setFilters: (filters: Partial<Store["filters"]>) => void
  resetFilters: () => void
}

export const useStore = create<Store>()(
  persist(
    (set, get) => ({
      // Cart
      cart: [],
      addToCart: (product, quantity = 1) => {
        const cart = get().cart
        const existingItem = cart.find((item) => item.id === product.id)

        if (existingItem) {
          set({
            cart: cart.map((item) => (item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item)),
          })
        } else {
          set({ cart: [...cart, { ...product, quantity }] })
        }
      },
      removeFromCart: (productId) => {
        set({ cart: get().cart.filter((item) => item.id !== productId) })
      },
      updateQuantity: (productId, quantity) => {
        if (quantity <= 0) {
          get().removeFromCart(productId)
          return
        }
        set({
          cart: get().cart.map((item) => (item.id === productId ? { ...item, quantity } : item)),
        })
      },
      clearCart: () => set({ cart: [] }),
      getCartTotal: () => {
        return get().cart.reduce((total, item) => total + item.price * item.quantity, 0)
      },
      getCartItemsCount: () => {
        return get().cart.reduce((total, item) => total + item.quantity, 0)
      },

      // User
      user: null,
      login: async (email, password) => {
        // Simulação de login - em produção, fazer chamada para API
        if (email === "admin@infortech.com.br" && password === "admin123") {
          const user: User = {
            id: 1,
            name: "Administrador",
            email: email,
            phone: "(11) 99999-9999",
            addresses: [],
            orders: [],
          }
          set({ user })
          return true
        }
        return false
      },
      logout: () => set({ user: null }),
      register: async (userData) => {
        // Simulação de registro - em produção, fazer chamada para API
        const user: User = {
          id: Date.now(),
          name: userData.name || "",
          email: userData.email || "",
          phone: userData.phone,
          addresses: [],
          orders: [],
        }
        set({ user })
        return true
      },
      updateUser: (userData) => {
        const currentUser = get().user
        if (currentUser) {
          set({ user: { ...currentUser, ...userData } })
        }
      },

      // Wishlist
      wishlist: [],
      addToWishlist: (product) => {
        const wishlist = get().wishlist
        if (!wishlist.find((item) => item.id === product.id)) {
          set({ wishlist: [...wishlist, product] })
        }
      },
      removeFromWishlist: (productId) => {
        set({ wishlist: get().wishlist.filter((item) => item.id !== productId) })
      },
      isInWishlist: (productId) => {
        return get().wishlist.some((item) => item.id === productId)
      },

      // Search
      searchQuery: "",
      setSearchQuery: (query) => set({ searchQuery: query }),
      searchResults: [],
      setSearchResults: (results) => set({ searchResults: results }),

      // Filters
      filters: {
        category: "",
        priceRange: [0, 10000],
        brand: "",
        rating: 0,
        inStock: false,
      },
      setFilters: (newFilters) => {
        set({ filters: { ...get().filters, ...newFilters } })
      },
      resetFilters: () => {
        set({
          filters: {
            category: "",
            priceRange: [0, 10000],
            brand: "",
            rating: 0,
            inStock: false,
          },
        })
      },
    }),
    {
      name: "infortech-store",
      partialize: (state) => ({
        cart: state.cart,
        user: state.user,
        wishlist: state.wishlist,
      }),
    },
  ),
)
