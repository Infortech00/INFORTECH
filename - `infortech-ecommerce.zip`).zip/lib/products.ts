import type { Product } from "./store"

export const products: Product[] = [
  {
    id: 1,
    name: "Processador AMD Ryzen 7 5800X",
    price: 1899.9,
    oldPrice: 2299.9,
    image: "/amd-ryzen-processor.png",
    category: "processadores",
    brand: "AMD",
    rating: 4.8,
    reviews: 156,
    stock: 15,
    description:
      "O AMD Ryzen 7 5800X é um processador de alto desempenho com 8 núcleos e 16 threads, ideal para jogos e tarefas de produtividade.",
    specifications: {
      Núcleos: "8",
      Threads: "16",
      "Frequência base": "3.8GHz",
      "Frequência máxima": "4.7GHz",
      "Cache L3": "32MB",
      TDP: "105W",
      Socket: "AM4",
    },
    features: [
      "8 núcleos e 16 threads",
      "Velocidade base de 3.8GHz",
      "Velocidade máxima de 4.7GHz",
      "Cache L3 de 32MB",
      "TDP de 105W",
      "Suporte a PCIe 4.0",
    ],
  },
  {
    id: 2,
    name: "Placa de Vídeo NVIDIA RTX 4060 8GB",
    price: 2499.9,
    oldPrice: 2799.9,
    image: "/nvidia-rtx-graphics-card.png",
    category: "placas-video",
    brand: "NVIDIA",
    rating: 4.7,
    reviews: 89,
    stock: 8,
    description:
      "Placa de vídeo NVIDIA GeForce RTX 4060 com 8GB GDDR6, ideal para jogos em 1080p e 1440p com ray tracing.",
    specifications: {
      GPU: "NVIDIA GeForce RTX 4060",
      Memória: "8GB GDDR6",
      Interface: "PCIe 4.0 x16",
      Saídas: "3x DisplayPort, 1x HDMI",
      Consumo: "115W",
      Comprimento: "244mm",
    },
    features: [
      "8GB de memória GDDR6",
      "Ray Tracing em tempo real",
      "DLSS 3.0",
      "Arquitetura Ada Lovelace",
      "Suporte a 4K",
      "PCIe 4.0",
    ],
  },
  {
    id: 3,
    name: 'Monitor Gamer 27" 165Hz IPS',
    price: 1599.9,
    oldPrice: 1899.9,
    image: "/gaming-monitor-display.png",
    category: "monitores",
    brand: "LG",
    rating: 4.6,
    reviews: 234,
    stock: 12,
    description: "Monitor gamer de 27 polegadas com painel IPS, taxa de atualização de 165Hz e resolução Full HD.",
    specifications: {
      Tamanho: '27"',
      Resolução: "1920x1080",
      "Taxa de atualização": "165Hz",
      "Tipo de painel": "IPS",
      "Tempo de resposta": "1ms",
      Conectividade: "HDMI, DisplayPort, USB",
    },
    features: [
      "Tela de 27 polegadas",
      "165Hz de taxa de atualização",
      "Painel IPS com cores vibrantes",
      "1ms de tempo de resposta",
      "G-Sync Compatible",
      "Ajuste de altura e inclinação",
    ],
  },
  {
    id: 4,
    name: "Cadeira Gamer Ergonômica",
    price: 899.9,
    oldPrice: 1199.9,
    image: "/ergonomic-gaming-chair.png",
    category: "cadeiras",
    brand: "DXRacer",
    rating: 4.5,
    reviews: 167,
    stock: 5,
    description: "Cadeira gamer ergonômica com apoio lombar, braços ajustáveis e reclinação até 180°.",
    specifications: {
      Material: "Couro sintético",
      "Peso máximo": "120kg",
      Altura: "Ajustável",
      Reclinação: "90° a 180°",
      Rodízios: "5 rodízios com freio",
      Garantia: "2 anos",
    },
    features: [
      "Design ergonômico",
      "Apoio lombar ajustável",
      "Braços 4D ajustáveis",
      "Reclinação até 180°",
      "Base de aço reforçada",
      "Espuma de alta densidade",
    ],
  },
  {
    id: 5,
    name: "Processador Intel Core i7-12700K",
    price: 2499.9,
    image: "/intel-core-i7.png",
    category: "processadores",
    brand: "Intel",
    rating: 4.7,
    reviews: 98,
    stock: 10,
    description:
      "Processador Intel Core i7 de 12ª geração com 12 núcleos e 20 threads, ideal para gaming e produtividade.",
    specifications: {
      Núcleos: "12 (8P + 4E)",
      Threads: "20",
      "Frequência base": "3.6GHz",
      "Frequência máxima": "5.0GHz",
      Cache: "25MB",
      TDP: "125W",
      Socket: "LGA1700",
    },
    features: [
      "12 núcleos híbridos",
      "20 threads",
      "Frequência turbo de 5.0GHz",
      "Suporte DDR5 e DDR4",
      "PCIe 5.0 e 4.0",
      "Intel UHD Graphics 770",
    ],
  },
  {
    id: 6,
    name: "Placa-Mãe ASUS ROG Strix Z690-F",
    price: 1899.9,
    image: "/asus-rog-motherboard.png",
    category: "placas-mae",
    brand: "ASUS",
    rating: 4.8,
    reviews: 76,
    stock: 7,
    description: "Placa-mãe ASUS ROG Strix Z690-F com chipset Intel Z690, suporte a DDR5 e PCIe 5.0.",
    specifications: {
      Socket: "LGA1700",
      Chipset: "Intel Z690",
      Memória: "DDR5-6000+ (OC)",
      "Slots PCIe": "3x PCIe 5.0/4.0 x16",
      SATA: "6x SATA 6Gb/s",
      "M.2": "4x M.2 slots",
    },
    features: [
      "Suporte a processadores Intel 12ª gen",
      "DDR5 até 6000MHz+",
      "PCIe 5.0 ready",
      "WiFi 6E integrado",
      "RGB Aura Sync",
      "Áudio SupremeFX",
    ],
  },
  {
    id: 7,
    name: "Memória RAM Corsair Vengeance 32GB DDR5",
    price: 1299.9,
    image: "/placeholder-duh3t.png",
    category: "memoria-ram",
    brand: "Corsair",
    rating: 4.6,
    reviews: 145,
    stock: 20,
    description: "Kit de memória RAM Corsair Vengeance LPX 32GB (2x16GB) DDR5-5600 com baixa latência.",
    specifications: {
      Capacidade: "32GB (2x16GB)",
      Tipo: "DDR5",
      Frequência: "5600MHz",
      Latência: "CL36",
      Voltagem: "1.25V",
      Perfil: "JEDEC",
    },
    features: [
      "32GB de capacidade total",
      "DDR5-5600 de alta velocidade",
      "Kit dual channel otimizado",
      "Baixo perfil para compatibilidade",
      "Testado para estabilidade",
      "Garantia vitalícia limitada",
    ],
  },
  {
    id: 8,
    name: "SSD NVMe Samsung 980 Pro 1TB",
    price: 899.9,
    image: "/placeholder-ju707.png",
    category: "armazenamento",
    brand: "Samsung",
    rating: 4.9,
    reviews: 312,
    stock: 25,
    description: "SSD NVMe Samsung 980 PRO de 1TB com interface PCIe 4.0 e velocidades de até 7.000 MB/s.",
    specifications: {
      Capacidade: "1TB",
      Interface: "PCIe 4.0 x4, NVMe 1.3c",
      "Leitura sequencial": "7.000 MB/s",
      "Escrita sequencial": "5.000 MB/s",
      Controlador: "Samsung Elpis",
      NAND: "3-bit MLC V-NAND",
    },
    features: [
      "Velocidades PCIe 4.0",
      "Até 7.000 MB/s de leitura",
      "Tecnologia V-NAND da Samsung",
      "Controlador Elpis otimizado",
      "Software Samsung Magician",
      "5 anos de garantia",
    ],
  },
  {
    id: 9,
    name: "Teclado Mecânico Logitech G Pro X",
    price: 899.9,
    image: "/placeholder.svg?height=200&width=200",
    category: "perifericos",
    brand: "Logitech",
    rating: 4.7,
    reviews: 189,
    stock: 15,
    description: "Teclado mecânico Logitech G PRO X com switches intercambiáveis e iluminação RGB.",
    specifications: {
      Layout: "TKL (87 teclas)",
      Switches: "GX Blue Clicky",
      Conectividade: "USB-C destacável",
      Iluminação: "RGB LIGHTSYNC",
      "Polling rate": "1000Hz",
      Dimensões: "361 x 153 x 34mm",
    },
    features: [
      "Switches mecânicos intercambiáveis",
      "Design TKL compacto",
      "RGB LIGHTSYNC personalizável",
      "Cabo USB-C destacável",
      "Estrutura de alumínio",
      "Software G HUB",
    ],
  },
  {
    id: 10,
    name: "Mouse Gamer Razer DeathAdder V2 Pro",
    price: 599.9,
    image: "/placeholder.svg?height=200&width=200",
    category: "perifericos",
    brand: "Razer",
    rating: 4.8,
    reviews: 267,
    stock: 18,
    description: "Mouse gamer sem fio Razer DeathAdder V2 Pro com sensor Focus+ 20K DPI e switches ópticos.",
    specifications: {
      Sensor: "Focus+ 20K DPI",
      Conectividade: "2.4GHz + Bluetooth",
      Bateria: "Até 120h",
      Switches: "Ópticos Razer",
      Peso: "88g",
      Dimensões: "127 x 61.7 x 42.7mm",
    },
    features: [
      "Sensor Focus+ 20.000 DPI",
      "Switches ópticos de 70M cliques",
      "Conectividade dupla sem fio",
      "Bateria de até 120 horas",
      "Design ergonômico",
      "RGB Chroma customizável",
    ],
  },
]

export const categories = [
  { id: "processadores", name: "Processadores", icon: "cpu" },
  { id: "placas-video", name: "Placas de Vídeo", icon: "gpu" },
  { id: "placas-mae", name: "Placas-Mãe", icon: "motherboard" },
  { id: "memoria-ram", name: "Memória RAM", icon: "memory" },
  { id: "armazenamento", name: "Armazenamento", icon: "hard-drive" },
  { id: "monitores", name: "Monitores", icon: "monitor" },
  { id: "perifericos", name: "Periféricos", icon: "keyboard" },
  { id: "cadeiras", name: "Cadeiras", icon: "chair" },
  { id: "notebooks", name: "Notebooks", icon: "laptop" },
  { id: "redes", name: "Redes", icon: "wifi" },
]

export const brands = [
  "AMD",
  "Intel",
  "NVIDIA",
  "ASUS",
  "MSI",
  "Gigabyte",
  "Corsair",
  "Kingston",
  "Samsung",
  "Western Digital",
  "Seagate",
  "LG",
  "Samsung",
  "AOC",
  "Logitech",
  "Razer",
  "HyperX",
  "SteelSeries",
]

export function searchProducts(query: string, filters?: any): Product[] {
  let filtered = products

  // Filtro por texto
  if (query) {
    const searchTerm = query.toLowerCase()
    filtered = filtered.filter(
      (product) =>
        product.name.toLowerCase().includes(searchTerm) ||
        product.description.toLowerCase().includes(searchTerm) ||
        product.brand.toLowerCase().includes(searchTerm) ||
        product.category.toLowerCase().includes(searchTerm),
    )
  }

  // Aplicar filtros
  if (filters) {
    if (filters.category) {
      filtered = filtered.filter((product) => product.category === filters.category)
    }
    if (filters.brand) {
      filtered = filtered.filter((product) => product.brand === filters.brand)
    }
    if (filters.priceRange) {
      filtered = filtered.filter(
        (product) => product.price >= filters.priceRange[0] && product.price <= filters.priceRange[1],
      )
    }
    if (filters.rating) {
      filtered = filtered.filter((product) => product.rating >= filters.rating)
    }
    if (filters.inStock) {
      filtered = filtered.filter((product) => product.stock > 0)
    }
  }

  return filtered
}

export function getProductsByCategory(category: string): Product[] {
  return products.filter((product) => product.category === category)
}

export function getProductById(id: number): Product | undefined {
  return products.find((product) => product.id === id)
}

export function getFeaturedProducts(): Product[] {
  return products.filter((product) => product.oldPrice).slice(0, 8)
}

export function getPopularProducts(): Product[] {
  return products.sort((a, b) => b.reviews - a.reviews).slice(0, 8)
}
